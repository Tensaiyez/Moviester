package com.example.tensaiye.popularmovie;


import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.tensaiye.popularmovie.API.RetrofitService;
import com.example.tensaiye.popularmovie.API.ServiceInterface;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {


    private static final String Tag = MainActivity.class.getSimpleName();
    private MovieAdapter mAdapter;

    private List<Movie> movies;
    private List<Review> reviewList;
    private int SpinnerPos = 0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Spinner spinner = findViewById(R.id.spinner_m);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.SortArray, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);


        if (savedInstanceState == null || !savedInstanceState.containsKey(Constants.MOVIEBUNDLE)) {
            if (isOnline()) {
                Fetch(Constants.Popular);

                spinner.setOnItemSelectedListener(this);
            } else if (!isOnline()) {
                Toast.makeText(this, "No Internet Connection...Please Connect To The Internet", Toast.LENGTH_SHORT).show();
            }


        } else {
            movies = savedInstanceState.getParcelableArrayList(Constants.MOVIEBUNDLE);
        }
    }
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_xml, menu);
        return true;
    }


    public void Fetch(String sort) {
        RetrofitService retrofitService=new RetrofitService();
        ServiceInterface serviceInterface = retrofitService.getRetrofit().create(ServiceInterface.class);
        Call<Basicmovie> call = serviceInterface.getMovies(sort,Constants.API_KEY);
        call.enqueue(new Callback<Basicmovie>() {
            @Override
            public void onResponse(Call<Basicmovie> call, Response<Basicmovie> response) {
                final RecyclerView recyclerView = (RecyclerView) findViewById(R.id.MovieList);
                recyclerView.setLayoutManager(new GridLayoutManager(MainActivity.this, 2));
                movies = response.body().getResults();
                mAdapter = new MovieAdapter(movies, R.layout.moviecard, getApplicationContext());
                recyclerView.setAdapter(mAdapter);

            }


            @Override
            public void onFailure(Call<Basicmovie> call, Throwable t) {
                Log.e(Tag, t.toString());
            }
        });


    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String word = parent.getItemAtPosition(position).toString();
        if(word.equals(Constants.Popular_xml_Val)){
            Fetch(Constants.Popular);
            TextView popular_tv=MainActivity.this.findViewById(R.id.PopularTitle);
            popular_tv.setVisibility(view.VISIBLE);
            TextView Highest_tv= MainActivity.this.findViewById(R.id.HighestTitle);
            Highest_tv.setVisibility(view.INVISIBLE);
        }
        else if(word.equals(Constants.TopRated_xml_Val)){
            Fetch(Constants.TopRated);
            TextView Highest_tv= MainActivity.this.findViewById(R.id.HighestTitle);
            Highest_tv.setVisibility(view.VISIBLE);
            TextView popular_tv=MainActivity.this.findViewById(R.id.PopularTitle);
            popular_tv.setVisibility(view.INVISIBLE);
        }

        if (SpinnerPos == position) {
            Fetch(Constants.Popular);
            TextView popular_tv=MainActivity.this.findViewById(R.id.PopularTitle);
            popular_tv.setVisibility(view.VISIBLE);
            TextView Highest_tv= MainActivity.this.findViewById(R.id.HighestTitle);
            Highest_tv.setVisibility(view.INVISIBLE);;
        }
    }


    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    // The method below checks if the phone is connected to a network.
    //https://developer.android.com/training/monitoring-device-state/connectivity-monitoring#java This site has helped me find a way in which to check the Network Status of the app.
    public boolean isOnline() {

        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkStatus= connectivityManager.getActiveNetworkInfo();
        return networkStatus != null;


    }
}





