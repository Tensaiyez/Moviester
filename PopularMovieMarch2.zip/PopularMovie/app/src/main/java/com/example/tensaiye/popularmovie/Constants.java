package com.example.tensaiye.popularmovie;

public class Constants {
    public static final String API_KEY = "873b531b1693c7dc14b2f4f11ddac99f";   // Please insert your personal API here
    public static final String MOVIEBUNDLE = "MOVIE_BUNDLE";
    public static final String BUNDLE_KEY = "bundle_key";
    public static final String Popular = "popular";
    public static final String TopRated = "top_rated";
    public static final String Popular_xml_Val="Popular";
    public static final String TopRated_xml_Val="Highest Rated";
}
