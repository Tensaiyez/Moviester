package com.example.tensaiye.popularmovie;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.tensaiye.popularmovie.API.RetrofitService;
import com.example.tensaiye.popularmovie.API.ServiceInterface;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class DetailActivity extends AppCompatActivity {


    private Movie movies;


    TextView mTitle;
    TextView mUserRating;
    TextView mReleaseDate;
    TextView mDescription;
    TextView mReviewContent;
    TextView mNoReview;

    String title;
    String releaseDate;
    String userRating;
    String overView;
    String poster;
    String id;
    String content;
    String author;
    private List<Review> reviewList = new ArrayList<>();
    private String Tag;
    private ReviewAdapter mReviewAdapter;
    final List<Review> reviewS = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        mNoReview= (TextView) findViewById(R.id.NoReview_tv);

        if (savedInstanceState == null || !savedInstanceState.containsKey(Constants.BUNDLE_KEY)) {
            Intent intent = getIntent();
            if (intent.hasExtra("original_name")) {
                title = intent.getStringExtra("original_name");
                releaseDate = intent.getStringExtra("release_date");
                userRating = intent.getStringExtra("user_rating");
                overView = intent.getStringExtra("overview");
                poster = intent.getStringExtra("backdrop_path");
                id = intent.getStringExtra("id");
                Log.d("whatever", id);

                FetchReviews(id);


                populateUI(movies);

            }
        }

    }

    private void FetchReviews(String movie_id) {
        RetrofitService retrofitService = new RetrofitService();
        ServiceInterface serviceInterface = retrofitService.getRetrofit().create(ServiceInterface.class);
        Call<BasicReview> call = serviceInterface.getReviews(movie_id, Constants.API_KEY);
        call.enqueue(new Callback<BasicReview>() {
            @Override
            public void onResponse(Call<BasicReview> call, Response<BasicReview> response) {
                final RecyclerView recyclerView = (RecyclerView) findViewById(R.id.Review_rv);
                recyclerView.setLayoutManager(new LinearLayoutManager(DetailActivity.this));
                reviewList = response.body().getResults();
                if(reviewList.isEmpty()){
                   mNoReview.setVisibility(View.VISIBLE);
                }
                mReviewAdapter=new ReviewAdapter(reviewList,getApplicationContext());
                recyclerView.setAdapter(mReviewAdapter);

            }

            @Override
            public void onFailure(Call<BasicReview> call, Throwable t) {

            }
        });
    }

    private void populateUI(Movie movie) {

        ImageView Imageshown = findViewById(R.id.Poster_tv);

        mTitle = (TextView) findViewById(R.id.Original_tv);
        mDescription = (TextView) findViewById(R.id.Overview_tv);
        mUserRating = (TextView) findViewById(R.id.Vote_tv);
        mReleaseDate = (TextView) findViewById(R.id.Release_tv);
        mReviewContent = (TextView) findViewById(R.id.Reviews_tv);


        mTitle.setText(title);
        mDescription.setText(overView);
        mUserRating.setText(userRating);
        mReleaseDate.setText(releaseDate);


        Picasso.with(this).load(poster).into(Imageshown);
    }

}
